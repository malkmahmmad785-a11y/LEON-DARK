# LEON DARK — Android project

This is a native Android Studio project using the two images supplied in the chat:
- `leon_background.jpg`: opening screen background
- `leon_logo.png`: in-app logo and launcher icon

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync (Android Gradle Plugin 8.6.1; compile SDK 35).
3. Choose **Build > Build APK(s)**.
4. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitation
This is a visual demo only. It does not connect to WhatsApp or determine whether a phone number is banned. WhatsApp does not provide a public official endpoint for checking arbitrary numbers' ban status. The app does not ask for WhatsApp passwords or verification codes.
