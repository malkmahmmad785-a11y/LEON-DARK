package com.leondark.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText phoneInput;
    private TextView result;
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(3, 4, 10));
        getWindow().setNavigationBarColor(Color.rgb(3, 4, 10));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(3, 4, 10));

        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.leon_background);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xAA000000, 0x66000000, 0xDD000000}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scroll = new ScrollView(this);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-1, -1);
        sp.topMargin = dp(32); sp.bottomMargin = dp(24);
        root.addView(scroll, sp);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setPadding(dp(26), dp(24), dp(26), dp(28));
        scroll.addView(panel);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.leon_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setStroke(dp(2), Color.rgb(255, 35, 45));
        logo.setBackground(circle);
        logo.setClipToOutline(true);
        LinearLayout.LayoutParams lpLogo = new LinearLayout.LayoutParams(dp(112), dp(112));
        lpLogo.bottomMargin = dp(12);
        panel.addView(logo, lpLogo);

        TextView title = new TextView(this);
        title.setText("LEON DARK");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        panel.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("NUMBER STATUS • DEMO");
        subtitle.setTextColor(Color.rgb(255, 65, 72));
        subtitle.setTextSize(12);
        subtitle.setLetterSpacing(0.14f);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sublp = new LinearLayout.LayoutParams(-1, -2);
        sublp.topMargin = dp(6); sublp.bottomMargin = dp(34);
        panel.addView(subtitle, sublp);

        TextView label = new TextView(this);
        label.setText("رقم الهاتف مع مفتاح الدولة");
        label.setTextColor(Color.WHITE);
        label.setTextSize(15);
        label.setGravity(Gravity.RIGHT);
        panel.addView(label, new LinearLayout.LayoutParams(-1, -2));

        phoneInput = new EditText(this);
        phoneInput.setSingleLine(true);
        phoneInput.setHint("+963 9XX XXX XXX");
        phoneInput.setHintTextColor(0xFFAAAAAA);
        phoneInput.setTextColor(Color.WHITE);
        phoneInput.setTextSize(17);
        phoneInput.setInputType(3);
        phoneInput.setPadding(dp(16), 0, dp(16), 0);
        GradientDrawable field = new GradientDrawable();
        field.setColor(0xCC08090F);
        field.setCornerRadius(dp(14));
        field.setStroke(dp(1), 0xFFFF303A);
        phoneInput.setBackground(field);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(56));
        fp.topMargin = dp(10); fp.bottomMargin = dp(16);
        panel.addView(phoneInput, fp);

        Button check = new Button(this);
        check.setText("فحص الرقم");
        check.setTextColor(Color.WHITE);
        check.setTextSize(16);
        check.setAllCaps(false);
        GradientDrawable btn = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF9B0008, 0xFFFF252F});
        btn.setCornerRadius(dp(14));
        check.setBackground(btn);
        check.setElevation(dp(4));
        panel.addView(check, new LinearLayout.LayoutParams(-1, dp(54)));

        result = new TextView(this);
        result.setTextColor(Color.WHITE);
        result.setTextSize(16);
        result.setGravity(Gravity.CENTER);
        result.setPadding(dp(10), dp(18), dp(10), dp(12));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(14);
        panel.addView(result, rp);

        TextView note = new TextView(this);
        note.setText("نسخة تجريبية — لا تتصل بخوادم واتساب ولا تستطيع تأكيد حالة حظر الرقم.");
        note.setTextColor(0xFFD0D0D0);
        note.setTextSize(11);
        note.setGravity(Gravity.CENTER);
        note.setPadding(dp(8), dp(28), dp(8), dp(4));
        panel.addView(note);

        check.setOnClickListener(v -> {
            String number = phoneInput.getText().toString().trim();
            if (number.isEmpty()) {
                result.setText("أدخل رقم الهاتف أولاً");
                result.setTextColor(0xFFFF7777);
                return;
            }
            result.setText("لا يمكن تأكيد حالة الحظر من هذه النسخة التجريبية.");
            result.setTextColor(Color.WHITE);
        });

        setContentView(root);
    }
}
